﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Summary description for dbconnection
/// </summary>
public class dbconnection
{   
    public static string constring;
    public static string msgException;
    

    public static SqlConnection newconnection()
    {
        try
        {
            SqlConnection con = new SqlConnection();
           // constring = "Data Source=SQL5011.Smarterasp.net;Initial Catalog=DB_9D8A1A_indata;User Id=DB_9D8A1A_indata_admin;Password=card1234;";
            constring = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\indata.mdf;Integrated Security=True;User Instance=True";            
            con.ConnectionString = constring;
            return con;
        }
        catch (Exception e)
        {
            return null;
        }
    }



    public static DataTable selectDatable(String sql)
    {
        DataTable dt = new DataTable();
        try
        {
            SqlConnection con = dbconnection.newconnection();
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            adapter.Fill(dt);
            con.Close();

        }
        catch (SqlException ex)
        {
            msgException = ex.ToString();
        }
        catch (Exception ex)
        {
            msgException = ex.ToString();
        }

        return dt;

    }    
    
    public static void updateData(String sql)
    {
        try
        {
            SqlConnection con = dbconnection.newconnection();
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();

        }
        catch (SqlException e)
        {
            e.ToString();
        }
        catch (Exception e)
        {
            e.ToString();
        }
        finally
        {

        }
    }

    public static Object selectImage(String sql)
    {
        SqlDataReader sdr = null;
        try
        {
            SqlConnection con = newconnection();
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            sdr = cmd.ExecuteReader();
            con.Close();

        }
        catch (SqlException ex)
        {
            ex.ToString();
        }
        return sdr;
    }


    public static void updateData()
    {
        throw new NotImplementedException();
    }

    public static SqlConnection getConnection()
    {
        SqlConnection conn = newconnection();
        return conn;
    }
}