﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class admin_category : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = dbconnection.newconnection();
        SqlCommand cmd = new SqlCommand("INSERT INTO tbl_cat (cat_name, max_player, bot, bet) VALUES ('"+TextBox1.Text+"',"+DropDownList1.SelectedValue+","+TextBox2.Text+","+TextBox3.Text+")", con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        GridView1.DataBind();
    }
}