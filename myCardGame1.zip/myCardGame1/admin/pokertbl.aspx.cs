﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class admin_pokertbl : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = dbconnection.newconnection();
        // insert values into database
        SqlCommand cmd = new SqlCommand("INSERT INTO pok_tbl (cat_id, no_player) VALUES(" + int.Parse(DropDownList4.SelectedValue.ToString()) + "," + int.Parse(DropDownList3.SelectedValue.ToString()) + ")", con);
        con.Open();
        cmd.ExecuteNonQuery();
        SqlCommand cmd1 = new SqlCommand("SELECT top 1 tbl_id FROM pok_tbl ORDER BY tbl_id DESC", con);
        SqlDataReader r = cmd1.ExecuteReader();
        r.Read();
        int id= int.Parse(r["tbl_id"].ToString());
        r.Close();
        String s1="INSERT INTO game_tbl (tbl_id,pot_chip) VALUES("+id+",0)";
        String s2 = "INSERT INTO display_cards (tbl_id) VALUES(" + id + ")";
        String s3 = "INSERT INTO display_result (tbl_id) VALUES(" + id + ")";
        String s4 = "INSERT INTO status_update (tbl_id) VALUES(" + id + ")";
        SqlCommand cmd2 = new SqlCommand(s1, con);
        SqlCommand cmd3 = new SqlCommand(s2, con);
        SqlCommand cmd4 = new SqlCommand(s3, con);
        SqlCommand cmd5 = new SqlCommand(s4, con);
        cmd2.ExecuteNonQuery();
        cmd3.ExecuteNonQuery();
        cmd4.ExecuteNonQuery();
        cmd5.ExecuteNonQuery();


        con.Close();
        GridView1.DataBind();
    }
}